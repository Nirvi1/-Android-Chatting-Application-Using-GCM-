<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", ""); // Place your Google API Key
?>